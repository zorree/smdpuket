part of 'currentdate_bloc.dart';

class CurrentdateEvent {}

class LoadDate extends CurrentdateEvent {}




